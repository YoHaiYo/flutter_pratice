abstract class CarInterface{

  void sell();

  // 인터페이스 파일내에서 함수를 정의하는 방법은 어떻게하는가?
  // benz 파일에서 오버라이드 하는 수밖에 없어요?

}